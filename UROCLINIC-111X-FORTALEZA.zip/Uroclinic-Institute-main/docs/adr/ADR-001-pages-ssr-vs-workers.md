# ADR-001 — Runtime
Decision: retain Cloudflare Workers + Static Assets. The uploaded repository is not Astro/Pages SSR; migrating platforms during hardening would add unrelated risk.
