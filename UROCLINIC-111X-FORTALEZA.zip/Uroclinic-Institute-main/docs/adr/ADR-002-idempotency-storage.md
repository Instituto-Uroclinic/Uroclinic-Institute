# ADR-002 — Idempotency storage
Decision: D1 with a PRIMARY KEY on `submission_id`. KV is not selected for the lock because the requirement is a uniqueness/atomicity boundary. D1 provisioning and environment-isolated database IDs remain manual Cloudflare actions.
