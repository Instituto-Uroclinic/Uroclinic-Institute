# ADR-003 — CRM system of record
HighLevel persistence determines lead success. Secondary notifications cannot convert a CRM failure into success.
