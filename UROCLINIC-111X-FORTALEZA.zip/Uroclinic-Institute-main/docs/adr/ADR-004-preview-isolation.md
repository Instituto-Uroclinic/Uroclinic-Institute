# ADR-004 — Preview isolation
Preview must use a separate D1 database and must not receive production HighLevel credentials by default. Production lead writes remain disabled until explicit environment configuration is completed.
