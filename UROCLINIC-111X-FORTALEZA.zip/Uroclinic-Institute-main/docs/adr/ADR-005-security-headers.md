# ADR-005 — Security headers
Worker-generated/API responses receive headers in code. Static assets retain `_headers`. CSP is scoped to current first-party assets and Cloudflare Turnstile.
